Thank you for downloading my Game :3

If you want to delete your savegame, simple delete the savegame.json.


Whats Planned:

- 10x10 Levels
- 15x15 Levels
- 20x20 Levels
- Levelgenerator (?)
- GRAPHICS, SOUNDS, MUSIC (?)
- Level Editor
